<?php $page= "about";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Domine:wght@400;500;600;700&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section2 -->
        <section class="section2 mt-4">
            <div class="container pb-5">
                <div class="row">
                    <div class="col-12 mt-md-3">
                        <div class="wrd-spe2">
                            <h3>Introducing Reader. A Stunning UI Kit Template for Blogs & Magazines</h3>
                            <p>entice, and convince consumers to take action. There is no <a href="#">magic formula</a> to write perfect ad copy; it is based on a number of factors, including ad placement, demographic, even the consumer’s mood when they see your ad. </p>

                            
                            <p>Place your description here. Free photo from <a href="#">Unsplash</a></p>

                            <p>You could do this with a headline or slogan (such as VW’s “Drivers Wanted” campaign), color or layout (Target’s new colorful, simple ads are a testimony to this) or illustration (such as the Red Bull characters or Zoloft’s depressed ball and his ladybug friend).  All good advertising copy is comprised of the same basic elements. </p>
                            <h4>Simple & Beautiful</h4>
                            <p>How you write your advertising copy will be based on where you will place your ad. If it’s a billboard ad, you’ll need a super catchy headline and simple design due to the speed at which people will pass. Online ads are similar; consumers are so inundated with Internet advertising that your ad must be quick and catchy. </p>

                            <blockquote>
                                Writing result-oriented ad copy is difficult, as it must appeal to, entice, and convince consumers to take action. There is no magic formula to write perfect ad copy.
                            </blockquote>

                            <p>What would the consumer gain by using your product or service? This could be tangible, like a free gift; prestige, power or fame. But remember: you must be able to make good on that promise, so don’t offer anything unreasonable.</p>

                            <h6>Template Features:</h6>
                            <ul>
                                <li>Beautifully Designed</li>
                                <li>Fully Responsive</li>
                                <li>CMS Content</li>
                                <li>Smooth Interactions</li>
                            </ul>

                            <p>Magazine advertising is the most versatile, but this is solely dependent on the size of your ad and how many other ads compete with yours. </p>

                            <h5>A Perfect Template for Your Blog or Magazine</h5>
                            <p>Grabbing the consumer’s attention isn’t enough; you have to keep that attention for at least a few seconds. This is where your benefits come into play or a product description that sets your offer apart from the others.</p>

                            <h6>Template Features:</h6>
                            <ol>
                                <li>Beautifully Designed</li>
                                <li>Fully Responsive</li>
                                <li>CMS Content</li>
                                <li>Smooth Interactions</li>
                            </ol>
                            <p>If you have a full page ad, feel free to experiment; more page space gives you more creative space. If the ad is tiny, you’ll need to keep things as simple as possible.</p>

                            <p>Posted 
                                Jan 16, 2019
                                in 
                                <a href="#">Culture</a>
                                category</p>
                        </div>  

                        <div class="card rounded-lg bg-light ml-auto col-md-11  py-5 px-5 mt-5">
                            <div class="row mt-2">
                                <div class="col-md-4 text-center">
                                    <img class="rounded-circle col-7 mr-1" src="assets/image/person.jpg">
                                    <h5 class="font-weight-bold mt-3 h5">Adrian Harris</h5>
                                    <a class="text-hvr1 mt-3" href="#">
                                        <small>VIEW POSTS</small>
                                    </a>
                                </div>
                                <div class="col-md-8 brd-left7 border border-right-0 border-bottom-0 border-top-0">
                                    <h6 class="mt-3">Post Tags:</h6>
                                    <div class="mt-2">
                                        <a class="btn btn btns9 btn-sm text-black1 border border-muted mt-2" href="#">
                                        Adventure
                                        </a>
                                        <a class="btn btn btns9 btn-sm text-black1 border border-muted mt-2" href="#">
                                            Adventure
                                        </a>
                                        <a class="btn btn btns9 btn-sm text-black1 border border-muted mt-2" href="#">
                                            Adventure
                                        </a>
                                        <a class="btn btn btns9 btn-sm text-black1 border border-muted mt-2" href="#">
                                            Adventure
                                        </a>
                                        <a class="btn btn btns9 btn-sm text-black1 border border-muted mt-2" href="#">
                                            Adventure
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 mt-5 mb-3 left-reveal">
                                <h4>More from 
                                    Culture
                                    category</h4>
                                <div class="progress mt-3" style="height: 1.9px;">
                                    <div class="progress-bar bg-dark" style="width:8%"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 mt-lg-0 mt-4 left-reveal">
                                <div class="row mt-3">
                                    <a class="col-md-4" href="#">
                                        <div class="parent rounded-lg mt-lg-0 mt-2">
                                            <div class="child">
                                                <img class="w-100" src="assets/image/img1.jpg">
                                            </div>
                                        </div>
                                    </a>
                                    <div class="col-md-8 pl-md-0 mt-md-0 mt-4 align-self-center">
                                        <a class="text-hvr1" href="#">
                                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                        </a>
                                        <p class="text-muted">
                                            <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                        </p>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-md-6 col-lg-6 mt-lg-0 mt-4 left-reveal">
                                <div class="row mt-3">
                                    <a class="col-md-4" href="#">
                                        <div class="parent rounded-lg mt-lg-0 mt-2">
                                            <div class="child">
                                                <img class="w-100" src="assets/image/img2.jpg">
                                            </div>
                                        </div>
                                    </a>
                                    <div class="col-md-8 pl-md-0 mt-md-0 mt-4 align-self-center">
                                        <a class="text-hvr1" href="#">
                                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                        </a>
                                        <p class="text-muted">
                                            <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                        </p>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-md-6 col-lg-6 mt-lg-0 mt-4 left-reveal">
                                <div class="row mt-3">
                                    <a class="col-md-4" href="#">
                                        <div class="parent rounded-lg mt-lg-0 mt-2">
                                            <div class="child">
                                                <img class="w-100" src="assets/image/img1.jpg">
                                            </div>
                                        </div>
                                    </a>
                                    <div class="col-md-8 pl-md-0 mt-md-0 mt-4 align-self-center">
                                        <a class="text-hvr1" href="#">
                                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                        </a>
                                        <p class="text-muted">
                                            <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                        </p>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-md-6 col-lg-6 mt-lg-0 mt-4 left-reveal">
                                <div class="row mt-3">
                                    <a class="col-md-4" href="#">
                                        <div class="parent rounded-lg mt-lg-0 mt-2">
                                            <div class="child">
                                                <img class="w-100" src="assets/image/img2.jpg">
                                            </div>
                                        </div>
                                    </a>
                                    <div class="col-md-8 pl-md-0 mt-md-0 mt-4 align-self-center">
                                        <a class="text-hvr1" href="#">
                                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                        </a>
                                        <p class="text-muted">
                                            <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card rounded-lg text-center p-5 px-5 mt-5">
                            <div class="row mt-2">
                                <div class="col-md-9 mx-auto d-block">
                                    <h4 class="font-weight-bold h5">Join Our Newsletter and Get the Latest
                                        Posts to Your Inbox</h4>
                                    <form class="d-md-flex">
                                        <input class="form-control p-4 bg-light mt-5" type="text" name="name" placeholder="Enter Your Email">
                                        <button class="btn9 btn btn btn-lg ml-3 mt-5 border-0 text-white" type="button"><small class="font-weight-bold">Subscribe</small></button>
                                    </form><br>
                                    <small>No spam ever. Read our <a class="text-hvr1" href="#"><u>Privacy Policy</u></a></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="section2 pt-4">
            <div class="container">
                <div class="bg-light brd2 p-5">
                    <div class="row justify-content-center py-5">
                        <div class="col-12 col-lg-8 col-xl-6 text-center left-reveal">
                            <h2>We Offer You Partnership</h2>
                            <p class="mt-4">We love to partner with brands and products that we believe in. If you feel that your company shares values and would
                            benefit our readers, we would love to talk about working together.</p>
        
                            <a href="#" class="btn9 btn btn px-5 py-3 mt-4 border-0">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>