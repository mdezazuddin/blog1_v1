<?php $page= "ebooks";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Domine:wght@400;500;600;700&display=swap" rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">


</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section1 -->
        <section class="section1 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="display-4">INTRODUCING: THE SEO PLAYBOOK</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 px-0">
                        <img class="w-100" src="assets/image/SEO-Playbook-mockup.png">
                    </div>
                    <div class="col-lg-6 pl-0 mt-5">
                        <h2>This Complete SEO Training for Beginners helps you with;</h2>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Essential fundamentals to SEO success</span></h5>
                        <h5 class="mt-4v"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to create an SEO friendly design that ranks well</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to grow 2x to 100x based on your current traffic levels</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Attract high-quality links no matter what niche you are and many more!</span></h5>
                        <h4 class="mt-4"><del class="text-danger mr-2">2,596 INR</del><span class="text-success mr-2">999 INR</span> /Offer valid till:</h4>
                        <div class="mt-4">
                            <a href="#" class="btn btn btn-lg btn9 px-5 py-3">More Details</a>
                            <a href="#" class="btn btn-success btn-lg px-5 py-3">
                                Buy Now for 999 INR</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <!-- section1 -->
        <section class="section1 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="display-4">AFFILIATE MARKETING BLUEPRINT</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 px-0">
                        <img class="w-100" src="assets/image/SEO-Playbook-mockup.png">
                    </div>
                    <div class="col-lg-6 pl-0 mt-5">
                        <h2>This Complete SEO Training for Beginners helps you with;</h2>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Essential fundamentals to SEO success</span></h5>
                        <h5 class="mt-4v"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to create an SEO friendly design that ranks well</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to grow 2x to 100x based on your current traffic levels</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Attract high-quality links no matter what niche you are and many more!</span></h5>
                        <h4 class="mt-4"><del class="text-danger mr-2">2,596 INR</del><span class="text-success mr-2">999 INR</span> /Offer valid till:</h4>
                        <div class="mt-4">
                            <a href="#" class="btn btn btn-lg btn9 px-5 py-3">More Details</a>
                            <a href="#" class="btn btn-success btn-lg px-5 py-3">
                                Buy Now for 999 INR</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <!-- section1 -->
        <section class="section1 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="display-4">KEYWORD RESEARCH MADE EASY</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 px-0">
                        <img class="w-100" src="assets/image/SEO-Playbook-mockup.png">
                    </div>
                    <div class="col-lg-6 pl-0 mt-5">
                        <h2>This Complete SEO Training for Beginners helps you with;</h2>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Essential fundamentals to SEO success</span></h5>
                        <h5 class="mt-4v"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to create an SEO friendly design that ranks well</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">How to grow 2x to 100x based on your current traffic levels</span></h5>
                        <h5 class="mt-4 media"><i class="fa fa-check-circle text-gold mr-3 fa-lg"></i><span class="media-body">Attract high-quality links no matter what niche you are and many more!</span></h5>
                        <h4 class="mt-4"><del class="text-danger mr-2">2,596 INR</del><span class="text-success mr-2">999 INR</span> /Offer valid till:</h4>
                        <div class="mt-4">
                            <a href="#" class="btn btn btn-lg btn9 px-5 py-3">More Details</a>
                            <a href="#" class="btn btn-success btn-lg px-5 py-3">
                                Buy Now for 999 INR</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <!-- section1 -->
        <section class="section1 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="display-4">COMBO OFFER (1199 INR ONLY):
                            KEYWORD RESEARCH + AFFILIATE MARKETING BLUEPRINT</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 mt-4">
                        <img class="w-100 mx-auto d-block" src="assets/image/SEO-Playbook-mockup.png">
                    </div>
                    <div class="col-lg-2 mt-4 align-self-center">
                        <img class="w-100 mx-auto d-block" src="assets/image/combo.png">
                    </div>
                    <div class="col-lg-5 mt-4">
                        <img class="w-100 mx-auto d-block" src="assets/image/SEO-Playbook-mockup.png">
                    </div>
                    <div class="col-lg-12 mt-4 text-center">
                        <h4><del class="text-danger mr-2">2,596 INR</del><span class="text-success mr-2">999 INR</span></h4>
                        <div class="mt-4">
                            <a href="#" class="btn btn-success btn-lg px-5 py-3">
                                Buy Today Only for 1199 INR</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>