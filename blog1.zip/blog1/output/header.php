
	<!--<div class="nav1">
		<nav class="navbar navbar-expand-md py-md-3">
			<div class="container">
				<a class="navbar-brand" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
				<button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="collapsibleNavbar">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item">
							<a class="nav-link <?php if($page=="blog"){echo "active-menu";} ?>" href="blog.php">BLOG</a>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="about"){echo "active-menu";} ?>" href="about.php">ABOUT</a>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="ebooks"){echo "active-menu";} ?>" href="ebooks.php">EBOOKS</a>
						</li> 
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="course"){echo "active-menu";} ?>" href="course.php">COURSES</a>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">CONTACT</a>
						</li>      
					</ul>
					<a href="#" class="text-decoration-none ml-4 text-hvr1" data-toggle="collapse" data-target="#demo">
						<i class="fa fa-search fa-lg"></i>
					</a>
				</div> 
			</div>
		</nav>
		<div id="demo" class="collapse">
			<div class="bg-light py-3 w-100">
				<div class="container">
					<div class="btn-group w-100">
						<input type="text" placeholder="Search" name="txtSearch" id="txtSearch"
						class="form-control border py-4 shadow-none">
						<a href="#" class="text-dark pl-4 align-self-center" data-toggle="collapse" data-target="#demo"><i class="fa fa-close fa-lg"></i></a>
					</div>
				</div>
			</div>
		</div>
		<hr class="my-0">
	</div>-->



	<div class="nav1">
		<nav class="navbar navbar-expand-md py-md-3">
			<div class="container">
				<a class="navbar-brand" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
				<button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="collapsibleNavbar">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item">
							<a class="nav-link <?php if($page=="blog"){echo "active-menu";} ?>" href="blog.php">BLOG</a>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link dropdown-toggle <?php if($page=="about"){echo "active-menu";} ?>" href="about.php">ABOUT</a>
							<ul class="shadow-sm rounded-lg mt-4">
								<li>
									<a href="about.php">Home</a>
								</li>
								<li>
									<a href="about.php">Category</a>
								</li>
								<li>
									<a href="about.php">Recipes</a>
								</li>
								<li>
									<a href="about.php">Pages</a>
								</li>
								<li>
									<a href="about.php">Elements</a>
								</li>
							</ul>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link dropdown-toggle <?php if($page=="ebooks"){echo "active-menu";} ?>" href="ebooks.php">EBOOKS</a>
							<ul class="shadow-sm rounded-lg mt-4">
								<li>
									<a href="about.php">Home</a>
								</li>
								<li>
									<a href="about.php">Category</a>
								</li>
								<li>
									<a href="about.php">Recipes</a>
								</li>
								<li>
									<a href="about.php">Pages</a>
								</li>
								<li>
									<a href="about.php">Elements</a>
								</li>
							</ul>
						</li> 
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="course"){echo "active-menu";} ?>" href="course.php">COURSES</a>
						</li>
						<li class="nav-item pl-md-3">
							<a class="nav-link <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">CONTACT</a>
						</li>    
					</ul>
					<a href="#" class="text-decoration-none ml-4 text-hvr1" data-toggle="collapse" data-target="#demo">
						<i class="fa fa-search fa-lg"></i>
					</a>
				</div>  
			</div>
		</nav>
		<div id="demo" class="collapse">
			<div class="bg-light py-3 w-100">
				<div class="container">
					<div class="btn-group w-100">
						<input type="text" placeholder="Search" name="txtSearch" id="txtSearch"
						class="form-control border py-4 shadow-none">
						<a href="#" class="text-dark pl-4 align-self-center" data-toggle="collapse" data-target="#demo"><i class="fa fa-close fa-lg"></i></a>
					</div>
				</div>
			</div>
		</div>
		<hr class="my-0">
	</div>


	